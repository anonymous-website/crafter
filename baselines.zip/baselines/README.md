# Crafter Baselines

This repository contains Docker containers for running various baselines on the
[Crafter](https://github.com/danijar/crafter) environment.
