import pathlib
import argparse

import chunkedfile
import crafter
import dreamerv2

parser = argparse.ArgumentParser()
boolean = lambda x: bool(['false', 'true'].index(x.lower()))
parser.add_argument('--logdir', type=str, default='logdir')
parser.add_argument('--reward', type=boolean, default=True)
parser.add_argument('--steps', type=float, default=5e6)
parser.add_argument('--sharding', type=int, default=3600)
args = parser.parse_args()

chunkedfile.patch_pathlib_append(args.sharding)

def make_env(config, mode='train'):
  env = crafter.Env(reward=args.reward)
  if mode == 'train':
    env = crafter.Recorder(
        env, pathlib.Path(args.logdir) / 'crafter-episodes',
        save_stats=True,
        save_video=False,
        save_episode=False,
    )
  return env

config = dreamerv2.Config(dreamerv2.configs['defaults'])
config = config.update({
    **dreamerv2.configs['crafter'],
    'logdir': args.logdir,
    'steps': args.steps,
    'expl_behavior': 'plan2explore',
    'expl_extr_scale': 2.0 if args.reward else 0.0,
    'expl_until': 0,
    'eval_every': 0,
})

outputs = [
    dreamerv2.TerminalOutput(),
]

dreamerv2.run(make_env, config, outputs)
