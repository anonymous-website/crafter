import argparse
import pathlib

import chunkedfile
import crafter
import dreamerv2

chunkedfile.patch_pathlib_append(3600)

parser = argparse.ArgumentParser()
boolean = lambda x: bool(['false', 'true'].index(x.lower()))
parser.add_argument('--logdir', type=str, default='logdir')
parser.add_argument('--reward', type=boolean, default=True)
parser.add_argument('--steps', type=float, default=5e6)
args = parser.parse_args()

def make_env(config, mode='train'):
  env = crafter.Env(reward=args.reward)
  if mode == 'train':
    env = crafter.Recorder(
        env, pathlib.Path(args.logdir) / 'crafter-episodes',
        save_stats=True,
        save_video=False,
        save_episode=False,
    )
  return env

config = dreamerv2.Config(dreamerv2.configs['defaults'])
config = config.update({
    **dreamerv2.configs['crafter'],
    'logdir': args.logdir,
    'steps': args.steps,
    'eval_every': 0,
})

outputs = [
    dreamerv2.TerminalOutput(),
]

dreamerv2.run(make_env, config, outputs)
